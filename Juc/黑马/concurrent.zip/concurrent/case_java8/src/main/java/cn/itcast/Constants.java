package cn.itcast;

public final class Constants {

    public static final String MP4_FULL_PATH = "G:\\第三方\\youtube\\Getting Started with Spring Boot-sbPSjI4tt10.mp4";
}
