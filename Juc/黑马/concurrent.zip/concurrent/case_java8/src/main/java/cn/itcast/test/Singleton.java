package cn.itcast.test;

enum Singleton {
    INSTANCE;
}
