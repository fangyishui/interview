package cn.itcast.concurrent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaseThirdpartApplicationTests {

    @Test
    void contextLoads() {
    }

}
